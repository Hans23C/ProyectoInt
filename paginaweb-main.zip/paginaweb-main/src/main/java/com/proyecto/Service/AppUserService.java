package com.proyecto.Service;
import com.proyecto.Entity.AppUser;
import java.util.List;

public interface AppUserService {
    public List<AppUser> listarUsuarios();
    
}
